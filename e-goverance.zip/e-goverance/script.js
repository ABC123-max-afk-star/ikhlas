const role = localStorage.getItem("role");
const currentUser = localStorage.getItem("currentUser");
const requestKey = "requests";

// Save request
if (document.getElementById("applyForm")) {
  document.getElementById("applyForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const type = document.getElementById("type").value;
    const details = document.getElementById("details").value;
    const requests = JSON.parse(localStorage.getItem(requestKey)) || [];
    requests.push({
      user: currentUser,
      type,
      details,
      status: "Pending",
      otp: "",
      certificate: ""
    });
    localStorage.setItem(requestKey, JSON.stringify(requests));
    alert("Request submitted");
    this.reset();
    renderTable();
  });
}

// Admin can upload certificate
if (document.getElementById("adminTable")) {
  const table = document.getElementById("adminTable").querySelector("tbody");
  const data = JSON.parse(localStorage.getItem(requestKey)) || [];
  data.forEach((req, i) => {
    if (req.status === "Approved" && !req.certificate) {
      const row = table.insertRow();
      row.innerHTML = `
        <td>${req.type}</td>
        <td>${req.user}</td>
        <td><button onclick="uploadCertificate(${i})">Upload</button></td>`;
    }
  });
}

// Hospital & Revenue approval
function renderDepartmentTable(typeFilter, tableId) {
  const data = JSON.parse(localStorage.getItem(requestKey)) || [];
  const table = document.getElementById(tableId).querySelector("tbody");
  table.innerHTML = "";
  data.forEach((req, i) => {
    if (req.status === "Pending" && req.type.includes(typeFilter)) {
      const row = table.insertRow();
      row.innerHTML = `
        <td>${req.type}</td>
        <td>${req.details}</td>
        <td>
          <button onclick="approveRequest(${i})">Approve</button>
          <button onclick="rejectRequest(${i})">Reject</button>
        </td>`;
    }
  });
}

function approveRequest(index) {
  const data = JSON.parse(localStorage.getItem(requestKey));
  data[index].status = "Approved";
  localStorage.setItem(requestKey, JSON.stringify(data));
  alert("Request Approved");
  location.reload();
}

function rejectRequest(index) {
  const data = JSON.parse(localStorage.getItem(requestKey));
  data[index].status = "Rejected";
  localStorage.setItem(requestKey, JSON.stringify(data));
  alert("Request Rejected");
  location.reload();
}

// Upload Certificate (Admin)
function uploadCertificate(index) {
  const data = JSON.parse(localStorage.getItem(requestKey));
  data[index].certificate = "certificate.pdf";
  data[index].otp = Math.floor(100000 + Math.random() * 900000).toString();
  localStorage.setItem(requestKey, JSON.stringify(data));
  alert("Certificate uploaded with OTP: " + data[index].otp);
  location.reload();
}

// Render user requests
function renderTable() {
  const table = document.getElementById("statusTable")?.querySelector("tbody");
  if (!table) return;
  const data = JSON.parse(localStorage.getItem(requestKey)) || [];
  table.innerHTML = "";
  data.forEach((req, i) => {
    if (req.user === currentUser) {
      table.innerHTML += `
        <tr>
          <td>${req.type}</td>
          <td>${req.status}</td>
          <td>${req.otp ? `<input placeholder="Enter OTP" id="otp${i}">` : "-"}</td>
          <td>
            ${req.certificate && req.otp ? 
              `<button onclick="downloadCert(${i})">Download</button>` : "Pending"}
          </td>
        </tr>`;
    }
  });
}

function downloadCert(i) {
  const otp = document.getElementById("otp" + i).value;
  const data = JSON.parse(localStorage.getItem(requestKey));
  if (otp === data[i].otp) {
    window.open("certificate.pdf", "_blank");
  } else {
    alert("Invalid OTP");
  }
}

// Admin publish schemes
if (document.getElementById("schemeForm")) {
  document.getElementById("schemeForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const title = document.getElementById("title").value;
    const desc = document.getElementById("desc").value;
    const list = document.getElementById("schemeList");
    const item = document.createElement("li");
    item.textContent = `${title}: ${desc}`;
    list.appendChild(item);
    this.reset();
  });
}

// Trigger page-specific logic
if (role === "user") renderTable();
if (role === "hospital") renderDepartmentTable("Birth", "hospitalTable");
if (role === "revenue") renderDepartmentTable("Income", "revenueTable");
